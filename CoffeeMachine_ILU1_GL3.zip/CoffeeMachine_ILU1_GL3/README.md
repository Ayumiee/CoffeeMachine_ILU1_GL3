# CoffeeMachine_ILU1_GL3
Exemple de code préexistant pour illustrer la vérification d'exigences

Les diverses etapes essaient d'illustrer les besoins d'amélioration du code, d'identification de cas d'erreur et de définition de scénarios de tests.
