package org.ratcm.exceptions;

public class InventoryException extends Exception {

	public InventoryException(String msg) {
		super(msg);
	}

}
