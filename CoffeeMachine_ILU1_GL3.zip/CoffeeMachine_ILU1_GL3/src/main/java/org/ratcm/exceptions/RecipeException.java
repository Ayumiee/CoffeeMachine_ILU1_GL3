package org.ratcm.exceptions;

public class RecipeException extends Exception {

	public RecipeException(String msg) {
		super(msg);
	}

}
